
async function generateQuiz() {
  const topic = document.getElementById("topic").value;
  const output = document.getElementById("output");
  output.innerText = "Generating quiz...";

  const response = await fetch("/api/quiz", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ topic }),
  });

  const data = await response.json();
  if (data.result) {
    output.innerText = data.result;
  } else {
    output.innerText = "Error: " + data.error;
  }
}
